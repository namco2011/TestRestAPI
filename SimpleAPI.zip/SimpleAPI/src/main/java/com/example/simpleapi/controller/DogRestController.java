package com.example.simpleapi.controller;

import com.example.simpleapi.domain.Message;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dog")
public class DogRestController {
  @RequestMapping(value = "list/all",produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public ResponseEntity<Message> getAll(){
    Map<String,List<String>> data = readData();
    if(data!=null){
      Message dogMessage= new Message();
      dogMessage.setMessage(data);
      dogMessage.setStatus("success");
      return new ResponseEntity<>(dogMessage,HttpStatus.OK);
    }
    return new ResponseEntity<>(HttpStatus.NOT_EXTENDED);
  }

  private Map<String,List<String>> readData(){
    ObjectMapper mapper = new ObjectMapper();
    InputStream inputStream = TypeReference.class.getResourceAsStream("/json/data.json");
    try{
      return mapper.readValue(inputStream,Map.class);
    }
    catch(IOException exception){
      System.out.println("cannot parse JSON data" + exception.getMessage());
    }
    return  null;
  }
}

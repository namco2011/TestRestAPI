package com.example.simpleapi.domain;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Message {
  private Map<String, List<String>> message;
  private String status;


  public Message(Map<String, List<String>> dogMessage, String status) {
    this.message = dogMessage;
    this.status = status;
  }

  public Map<String, List<String>> getMessage() {
    return message;
  }

  public Message setMessage(Map<String, List<String>> message) {
    this.message = message;
    return this;
  }

  public Message() { }


  public String getStatus() {
    return status;
  }

  public Message setStatus(String status) {
    this.status = status;
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Message that = (Message) o;
    return Objects.equals(message, that.message) && Objects.equals(status, that.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(message, status);
  }
}
